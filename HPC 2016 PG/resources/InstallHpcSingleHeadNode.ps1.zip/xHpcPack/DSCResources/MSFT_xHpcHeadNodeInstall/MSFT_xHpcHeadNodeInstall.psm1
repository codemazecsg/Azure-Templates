#
# xHpcPackInstall: DSC resource to install HPC Pack.
#

function Get-TargetResource
{
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SetupPkgPath,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint,

        [parameter(Mandatory = $false)]
        [string] $ClusterName = "",

        [parameter(Mandatory = $false)]
        [string] $SQLServerInstance = "",

        [parameter(Mandatory = $false)]
        [System.Management.Automation.PSCredential] $SQLCredential,

        [parameter(Mandatory = $false)]
        [Boolean] $LinuxCommOverHttp = $false
    )

    return $PSBoundParameters
}

function Set-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SetupPkgPath,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint,

        [parameter(Mandatory = $false)]
        [string] $ClusterName = "",

        [parameter(Mandatory = $false)]
        [string] $SQLServerInstance = "",

        [parameter(Mandatory = $false)]
        [System.Management.Automation.PSCredential] $SQLCredential,

        [parameter(Mandatory = $false)]
        [Boolean] $LinuxCommOverHttp = $false
    )

    $downloader = New-Object System.Net.WebClient
    # Download the setup package if it is an http/https url
    if($SetupPkgPath -match "^https?://")
    {
        $setupPkgUrl = $SetupPkgPath
        $SetupPkgPath = Join-Path "$env:windir\Temp" $($setupPkgUrl -split '/')[-1]
        DownloadFile -Downloader $downloader -SourceUrl $setupPkgUrl -DestPath $SetupPkgPath
    }

    if((Test-Path -Path $SetupPkgPath -PathType Leaf) -and [IO.Path]::GetExtension($SetupPkgPath) -eq ".zip")
    {
        $basetgtdir = $SetupPkgPath.Substring(0, $SetupPkgPath.LastIndexOf('.')) + '_HPC'
        $tgtdir = $basetgtdir
        $index = 0
        while(Test-Path -Path $tgtdir -PathType Container)
        {
            try
            {
                Remove-Item -Path $tgtdir -Recurse -Force -ErrorAction Stop
                break
            }
            catch
            {
                $tgtdir = "$basetgtdir" + "_$index"
            }
        }

        [System.Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem') | Out-Null
        [System.IO.Compression.ZipFile]::ExtractToDirectory($SetupPkgPath, $tgtdir) | Out-Null
    }
    else
    {
        $tgtdir = $SetupPkgPath
    }

    $pfxCert = Get-Item Cert:\LocalMachine\My\$SSLThumbprint -ErrorAction SilentlyContinue
    if($pfxCert -eq $null)
    {
        throw "The certificate with thumbprint '$SSLThumbprint' doesn't exist under Cert:\LocalMachine\My"
    }

    if($pfxCert.Subject -eq $pfxCert.Issuer)
    {
        if(-not (Test-Path Cert:\LocalMachine\Root\$SSLThumbprint))
        {
            Write-Verbose "Installing certificate to Cert:\LocalMachine\Root"
            $cerFileName = "$env:Temp\HpcPackComm.cer"
            Export-Certificate -Cert "Cert:\LocalMachine\My\$SSLThumbprint" -FilePath $cerFileName | Out-Null
            Import-Certificate -FilePath $cerFileName -CertStoreLocation Cert:\LocalMachine\Root  | Out-Null
            Remove-Item $cerFileName -Force -ErrorAction SilentlyContinue
        }
    }

    if(-not $ClusterName)
    {
        $ClusterName = $env:ComputerName
    }

    $setupArg = "-unattend -Quiet -HeadNode -HeadNodeList:`"$HeadNodeList`" -ClusterName:$ClusterName -SSLThumbprint:$SSLThumbprint"
    if($LinuxCommOverHttp)
    {
        $setupArg += " -LinuxCommOverHttp"
    }
    if($SQLServerInstance)
    {
        if($PSBoundParameters.ContainsKey('SQLCredential'))
        {
            $secinfo = "Integrated Security=False;User ID={0};Password={1}" -f $SQLCredential.UserName, $SQLCredential.GetNetworkCredential().Password
        }
        else
        {
            $secinfo = "Integrated Security=True"
        }

        $mgmtConstr = "Data Source=$SQLServerInstance;Initial Catalog=HpcManagement;$secinfo"
        $schdConstr = "Data Source=$SQLServerInstance;Initial Catalog=HpcScheduler;$secinfo"
        $monConstr  = "Data Source=$SQLServerInstance;Initial Catalog=HPCMonitoring;$secinfo"
        $rptConstr  = "Data Source=$SQLServerInstance;Initial Catalog=HPCReporting;$secinfo"
        $diagConstr = "Data Source=$SQLServerInstance;Initial Catalog=HPCDiagnostics;$secinfo"
        $setupArg = "$setupArg -MGMTDBCONSTR:`"$mgmtConstr`" -SCHDDBCONSTR:`"$schdConstr`" -RPTDBCONSTR:`"$rptConstr`" -DIAGDBCONSTR:`"$diagConstr`" -MONDBCONSTR:`"$monConstr`""           
    }

    $fixedARMConfigFile = [System.IO.Path]::Combine([System.Environment]::GetEnvironmentVariable("CCP_HOME", "Machine"), "Bin\AzureRmConfig_5.1.1.xml")
    if(Test-Path $fixedARMConfigFile)
    {
        [System.Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem') | Out-Null
        $armConfigFullNameInZip = "ManagementStatelessServicePkg\Code\AzureRmConfig.xml"
        Write-Verbose "Update $armConfigFullNameInZip in HpcApplicationType.sfpkg with $fixedARMConfigFile."
        $sfpkg = [System.IO.Compression.ZipFile]::Open("$tgtdir\setup\HpcApplicationType.sfpkg", "Update")
        $armConfigEntry = $sfpkg.Entries | ?{$_.FullName -eq $armConfigFullNameInZip} | select -First(1)
        if($null -ne $armConfigEntry)
        {
            $armConfigEntry.Delete() | Out-Null
        }
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($sfpkg, $fixedARMConfigFile, $armConfigFullNameInZip) | Out-Null
        $sfpkg.Dispose()
    }

    $retry = 0
    while($true)
    {
        Write-Verbose "Installing HPC Pack Head Node"
        $p = Start-Process -FilePath "$tgtdir\setup.exe" -ArgumentList $setupArg -PassThru -Wait
        if($p.ExitCode -eq 0)
        {
            Write-Verbose "Succeed to Install HPC Pack Head Node"
            break
        }
        if($p.ExitCode -eq 3010)
        {
            Write-Verbose "Succeed to Install HPC Pack Head Node, a reboot is required."
            $global:DSCMachineStatus = 1
            break
        }

        if($retry++ -lt 5)
        {
            Write-Warning "Failed to Install HPC Pack Head Node (errCode=$($p.ExitCode)), retry later..."
            Clear-DnsClientCache
            Start-Sleep -Seconds ($retry * 20)
        }
        else
        {
            if($p.ExitCode -eq 13818)
            {
                throw "Failed to Install HPC Pack Head Node (errCode=$($p.ExitCode)): the certificate doesn't meet the requirements."
            }
            else
            {
                throw "Failed to Install HPC Pack Head Node (errCode=$($p.ExitCode))"
            }
        }
    }
    
    $orgARMConfigFile = [System.IO.Path]::Combine([System.Environment]::GetEnvironmentVariable("CCP_HOME", "Machine"), "Bin\AzureRmConfig.xml")
    if(Test-Path $fixedARMConfigFile)
    {
        if(Test-Path $orgARMConfigFile)
        {
            Write-Verbose "Replace $orgARMConfigFile with $fixedARMConfigFile."
            Copy-Item $fixedARMConfigFile -Destination $orgARMConfigFile -Force -ErrorAction SilentlyContinue
        }
        
        Remove-Item $fixedARMConfigFile -Force -ErrorAction SilentlyContinue
    }
}

function Test-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SetupPkgPath,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint,

        [parameter(Mandatory = $false)]
        [string] $ClusterName = "",

        [parameter(Mandatory = $false)]
        [string] $SQLServerInstance = "",

        [parameter(Mandatory = $false)]
        [System.Management.Automation.PSCredential] $SQLCredential,

        [parameter(Mandatory = $false)]
        [Boolean] $LinuxCommOverHttp = $false
    )
    
    $serverGuid = "02985CCE-D7D5-40FF-9C81-6334523210F9"
    if($null -eq (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | ?{$_.UninstallString -and $_.UninstallString -match $serverGuid}))
    {
        return $false
    }

    $hpcRegKey = Get-Item HKLM:\SOFTWARE\Microsoft\HPC -ErrorAction SilentlyContinue
    if($hpcRegKey)
    {
        $roles = $hpcRegKey | Get-ItemProperty | Select -Property InstalledRole
        if($roles -and ($roles.InstalledRole -contains 'HN'))
        {
            $fabricSvc = Get-Service -Name 'fabricHostSvc' -ErrorAction SilentlyContinue
            return ($null -ne $fabricSvc)
        }
    }

    return $false
}

function DownloadFile
{
    param(
        [parameter(Mandatory = $false)]
        [System.Net.WebClient] $Downloader = $null,

        [parameter(Mandatory = $true)]
        [string] $SourceUrl,

        [parameter(Mandatory = $true)]
        [string] $DestPath
    )

    if($Downloader -eq $null)
    {
        $Downloader = New-Object System.Net.WebClient
    }

    $fileName = $($SourceUrl -split '/')[-1]
    if(Test-Path -Path $DestPath -PathType Container)
    {
        $DestPath = [IO.Path]::Combine($DestPath, $fileName)
    }

    $downloadRetry = 0
    while($true)
    {
        try
        {
            if(Test-Path -Path $DestPath)
            {
                Remove-Item -Path $DestPath -Force -Confirm:$false -ErrorAction SilentlyContinue
            }

            Write-Verbose "Downloading $SourceUrl to $DestPath(Retry=$downloadRetry)."
            $Downloader.DownloadFile($SourceUrl, $DestPath)
            Write-Verbose "Downloaded $SourceUrl to $DestPath."
            break
        }
        catch
        {
            if($downloadRetry -lt 10)
            {
                Write-Verbose ("Failed to download files, retry after 20 seconds:" + $_)
                Clear-DnsClientCache
                Start-Sleep -Seconds 20
                $downloadRetry++
            }
            else
            {
               throw "Failed to download files after 10 retries"
            }
        }
    }
}


Export-ModuleMember -Function *-TargetResource
