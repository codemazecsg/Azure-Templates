#
# xHpcPackInstall: DSC resource to install HPC Pack.
#

function Get-TargetResource
{
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("ComputeNode", "BrokerNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint,

        [parameter(Mandatory = $false)]
        [Boolean] $NonDomainRole = $false
    )

    return $PSBoundParameters
}

function Set-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("ComputeNode", "BrokerNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint,

        [parameter(Mandatory = $false)]
        [Boolean] $NonDomainRole = $false
    )

    if(!(ValidateInstalledRoles -NodeType $NodeType))
    {
        throw "HPC $NodeType was not pre-installed"
    }
    

    $pfxCert = Get-Item Cert:\LocalMachine\My\$SSLThumbprint -ErrorAction SilentlyContinue
    if($pfxCert -eq $null)
    {
        throw "The certificate Cert:\LocalMachine\My\$SSLThumbprint doesn't exist"
    }

    if($pfxCert.Subject -eq $pfxCert.Issuer)
    {
        if(-not (Test-Path Cert:\LocalMachine\Root\$SSLThumbprint))
        {
            Write-Verbose "Installing certificate to Cert:\LocalMachine\Root"
            $cerFileName = "$env:Temp\HpcPackComm.cer"
            Export-Certificate -Cert "Cert:\LocalMachine\My\$SSLThumbprint" -FilePath $cerFileName | Out-Null
            Import-Certificate -FilePath $cerFileName -CertStoreLocation Cert:\LocalMachine\Root  | Out-Null
            Remove-Item $cerFileName -Force -ErrorAction SilentlyContinue
        }
    }

    $dwNonDomain = 0
    if($NonDomainRole)
    {
        Write-Verbose "The node is a non domain role"
        $dwNonDomain = 1
    }

    Write-Verbose "Set HPC registry values ..."
    Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\HPC -Name ClusterConnectionString -Value $HeadNodeList
    Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\HPC -Name SSLThumbPrint -Value $SSLThumbprint
    Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\HPC -Name NonDomainRole -Value $dwNonDomain -Type DWord
    if(Test-Path HKLM:\SOFTWARE\Wow6432Node\Microsoft\HPC)
    {
        Set-ItemProperty -Path HKLM:\SOFTWARE\Wow6432Node\Microsoft\HPC -Name ClusterConnectionString -Value $HeadNodeList
        Set-ItemProperty -Path HKLM:\SOFTWARE\Wow6432Node\Microsoft\HPC -Name SSLThumbPrint -Value $SSLThumbprint
        Set-ItemProperty -Path HKLM:\SOFTWARE\Wow6432Node\Microsoft\HPC -Name NonDomainRole -Value $dwNonDomain -Type DWord
    }

    Write-Verbose "Set environment varaible CCP_SCHEDULER and CCP_CONNECTIONSTRING value as $HeadNodeList"
    [Environment]::SetEnvironmentVariable("CCP_SCHEDULER", $HeadNodeList, [System.EnvironmentVariableTarget]::Machine)
    [Environment]::SetEnvironmentVariable("CCP_CONNECTIONSTRING", $HeadNodeList, [System.EnvironmentVariableTarget]::Machine)

    # Restart the HPC services so that we can remove the log files
    if($NodeType -eq 'ComputeNode')
    {
        $hpcServices = @("HpcManagement", "HpcNodeManager", "msmpi", "HpcMonitoringClient", "HpcSoaDiagMon")
    }
    elseif($NodeType -eq 'BrokerNode')
    {
        $hpcServices = @("HpcManagement", "HpcNodeManager", "msmpi", "HpcMonitoringClient", "HpcSoaDiagMon", "HpcBroker")
    }
    else
    {
        $hpcServices = @("HpcNodeManager", "msmpi", "HpcMonitoringClient", "HpcSoaDiagMon")
    }
    foreach($svc in $hpcServices)
    {
        Write-Verbose "Restarting service $svc"
        Set-Service -Name $svc -StartupType Automatic
        Restart-Service -Name $svc -Force
    }
}

function Test-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("ComputeNode", "BrokerNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SSLThumbprint,

        [parameter(Mandatory = $false)]
        [Boolean] $NonDomainRole = $false
    )
    
    if(ValidateInstalledRoles -NodeType $NodeType)
    {
        $nmSvc = Get-WmiObject -Class Win32_Service -Property StartMode -Filter "Name='HpcNodeManager'"
        if(($null -eq $nmSvc) -or ($nmSvc.StartMode -ne "Auto"))
        {
            return $false
        }

        $dwNonDomain = 0
        if($NonDomainRole)
        {
            Write-Verbose "Non domain joined node"
            $dwNonDomain = 1
        }

        $hpcProperties = Get-Item HKLM:\SOFTWARE\Microsoft\HPC -ErrorAction SilentlyContinue | Get-ItemProperty | Select -Property ClusterConnectionString, SSLThumbprint, NonDomainRole
        if($hpcProperties -and ($hpcProperties.ClusterConnectionString -eq $HeadNodeList) -and ($hpcProperties.SSLThumbprint -eq $SSLThumbprint) -and ($hpcProperties.NonDomainRole -eq $dwNonDomain))
        {
            return $true
        }
    }

    return $false
}

function ValidateInstalledRoles
{
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("ComputeNode", "BrokerNode", "HeadNodePreReq")]
        [string] $NodeType
    )

    if($NodeType -eq 'ComputeNode')
    {
        $desiredRoles = @('CN')
    }
    elseif($NodeType -eq 'BrokerNode')
    {
        $desiredRoles = @('CN','BN')
    }
    else
    {
        $desiredRoles = @('CN','HN')
    }

    $hpcRegKey = Get-Item HKLM:\SOFTWARE\Microsoft\HPC -ErrorAction SilentlyContinue
    if($hpcRegKey)
    {
        $roles = $hpcRegKey | Get-ItemProperty | Select -Property InstalledRole
        if($roles -and ($null -ne $roles.InstalledRole) -and !(Compare-Object -ReferenceObject $desiredRoles -DifferenceObject $roles.InstalledRole))
        {
            return $true
        }
    }
    
    return $false
}

Export-ModuleMember -Function *-TargetResource
